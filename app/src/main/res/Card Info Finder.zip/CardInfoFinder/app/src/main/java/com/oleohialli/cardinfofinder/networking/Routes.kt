package com.oleohialli.cardinfofinder.networking

object Routes {

    const val BASE_URL = "https://lookup.binlist.net/"

}