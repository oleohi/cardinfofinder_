package com.oleohialli.cardinfofinder.networking.service

import com.oleohialli.cardinfofinder.models.ResponseDTO
import retrofit2.Call
import retrofit2.http.GET

interface CardInfoService {

    @GET
    fun getCardInfo(): Call<ResponseDTO>

}